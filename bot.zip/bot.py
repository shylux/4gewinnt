#---------------------------------------------------------------------#
# Four In A Row AI Challenge - Starter Bot                            #
# ============                                                        #
#                                                                     #
# Last update: 30 Mar, 2016                                           #
#                                                                     #
# @author Lukas Knoepfel <shylux@gmail.com>                           #
# @version 1.0                                                        #
# @license MIT License (http://opensource.org/licenses/MIT)           #
#---------------------------------------------------------------------#

from sys import stdin, stdout
import numpy as np
import time


class Bot(object):

    settings = dict()
    round = -1
    board = np.zeros((6, 7), dtype=np.uint8)  # Access with [row_nr, col_nr]. [0,0] is on the top left.
    timeout = -1
    last_played_stone_col = -1
    last_played_stone_row = -1

    def make_turn(self):
        """ This method is for calculating and executing the next play.
            Make the play by calling place_disc exactly once.
        """
        raise NotImplementedError()

    def place_disc(self, column):
        """ Writes your next play in stdout. """
        stdout.write("place_disc %d\n" % column)
        stdout.flush()

    def simulate_place_disc(self, board, col_nr, curr_player):
        """ Returns a board state after curr_player placed a disc in col_nr.
            This is a simulation and doesn't update the actual playing board. """
        if board[0, col_nr] != 0:
            raise Bot.ColumnFullException()
        new_board = np.copy(board)
        for row_nr in reversed(range(self.rows())):
            if new_board[row_nr, col_nr] == 0:
                new_board[row_nr, col_nr] = curr_player
                self.last_played_stone_col = col_nr
                self.last_played_stone_row = row_nr
                return new_board

    def id(self):
        """ Returns own bot id. """
        return self.settings['your_botid']

    def rows(self):
        """ Returns amount of rows. """
        return self.settings['field_rows']

    def cols(self):
        """ Returns amount of columns. """
        return self.settings['field_columns']

    def current_milli_time(self):
        """ Returns current system time in milliseconds. """
        return int(round(time.time() * 1000))

    def set_timeout(self, millis):
        """ Sets time left until timeout in milliseconds. """
        self.timeout = self.current_milli_time() + millis

    def time_left(self):
        """ Get how much time is left until a timeout. """
        return self.timeout - self.current_milli_time()

    def run(self):
        """ Main loop.
        """
        while not stdin.closed:
            try:
                rawline = stdin.readline()

                # End of file check
                if len(rawline) == 0:
                    break

                line = rawline.strip()

                # Empty lines can be ignored
                if len(line) == 0:
                    continue

                parts = line.split()

                command = parts[0]

                self.parse_command(command, parts[1:])

            except EOFError:
                return

    def parse_command(self, command, args):
        if command == 'settings':
            key, value = args
            if key in ('timebank', 'time_per_move', 'your_botid', 'field_columns', 'field_rows'):
                value = int(value)
            self.settings[key] = value

        elif command == 'update':
            sub_command = args[1]
            args = args[2:]

            if sub_command == 'round':
                self.round = int(args[0])
            elif sub_command == 'field':
                self.parse_field(args[0])

        elif command == 'action':
            self.set_timeout(int(args[1]))
            self.make_turn()

    def parse_field(self, str_field):
        self.board = np.fromstring(str_field.replace(';', ','), sep=',', dtype=np.uint8).reshape(self.rows(), self.cols())

    class ColumnFullException(Exception):
        """ Raised when attempting to place disk in full column. """
from random import getrandbits
import numpy as np


class zobristHash:

    def __init__(self, x, y, states):
        self.states = states
        self.x = x
        self.y = y
        self.map = np.zeros((x, y, states), dtype=np.long)
           
    def precomupte(self):
        
        for x in range(self.x):
            for y in range(self.y):
                for state in range(self.states):
                    self.map[x][y][state] = getrandbits(24)

    def calculate_hash(self, last_hash, x, y, state):
        return last_hash ^ self.map[x][y][state]
    
    def calculate_board_hash(self, board):
        h = 0
        for x in range(self.x):
            for y in range(self.y):
                if board[x][y] != 0:
                    h = h ^ self.map[x][y][board[x][y] - 1]
        return h

# zh = zobristHash(2,7,6)
# zh.precomupte()
# print(zh.map)
# print(zh.calculate_hash(zh.calculate_hash(0,1,5,0),3,1,1))
# print(zh.calculate_hash(zh.calculate_hash(0,3,1,1),1,5,0))


class TranspositionTable(object):
    def __init__(self, x, y, states):
        # hash-map
        self.dict = {}
        self.zobristHash = zobristHash(x, y, states)
        self.zobristHash.precomupte()
        
    # Return
    def get_entry(self, node, x, y, state):
        
        board_key = self.zobristHash.calculate_hash(node.parent.hash, x, y, state-1)
        obj = self.dict.get(board_key)
        
        if not obj or obj.node == node:
            return None 
        else:
            return self.dict[board_key] 
            
    def add_entry(self, node, x, y, state):
        board_key = self.zobristHash.calculate_hash(node.parent.hash, x, y, state-1)
        node.hash = board_key
        self.dict[board_key] = TranspositionEntry(node)

    def calculate_board_hash(self, board):
        return self.zobristHash.calculate_board_hash(board)


class TranspositionEntry:
    def __init__(self, node):
        self.node = node
import sys


class Node(object):

    def __init__(self, state, parent=None):
        if parent:
            self.max_node = not parent.max_node

        self.state = state
        self.children = []
        self.parent = parent

    def __repr__(self):
        if len(self.children) == 0:
            return str(self.state)
        else:
            return "(" + ", ".join([str(child) for child in self.children]) + ")"


class MinMax(object):
    def __init__(self):
        self.root = None

    def heuristic(self, node):
        raise NotImplementedError()

    def expand_node(self, state):
        raise NotImplementedError()

    def minmax(self, max_depth, node=None, alpha=-sys.maxsize, beta=sys.maxsize):
        
        if max_depth == 0:  # leaf node
            return self.heuristic(node)

        if len(node.children) == 0:
            self.expand_node(node)

        if len(node.children) == 0:
            node.value = self.heuristic(node)
            return node.value

        node.value = -sys.maxsize if node.max_node else sys.maxsize  # initialize with worst value
        for child in node.children:
            child_value = self.minmax(max_depth-1, child, alpha, beta)
            if node.max_node:
                node.value = max(node.value, child_value)
                alpha = node.value
                if alpha >= beta:  # check for pruning
                    break
            else:
                node.value = min(node.value, child_value)
                beta = node.value
                if beta <= alpha:
                    break

        # sort for optimization
        if node.max_node:
            node.children.sort(key=lambda n: n.value, reverse=True)
        else:
            node.children.sort(key=lambda n: n.value) 

        return node.value
import sys
import numpy as np
import time


class SupiBot(Bot, MinMax):

    def __init__(self, debugMode = False):
        self.root = None
        self.debugMode = debugMode
        self.player_id_made_last_turn = None
        self.cached_lines_coords = None
        self.transTable = TranspositionTable(6,7,2)
        self.lastDepth = 0
        self.col_order = list(range(0,7))
        self.col_order[0] = 3
        self.col_order[1] = 4
        self.col_order[2] = 2
        self.col_order[3] = 5
        self.col_order[4] = 1
        self.col_order[5] = 6
        self.col_order[6] = 0
        
    def make_turn(self):
        
        # do this in the first turn
        if not self.root:
            self.root = Node(self.board)
            self.root.max_node = True
            self.root.value = 0
            self.root.hash = None
        
        board_hash = self.transTable.calculate_board_hash(self.board)

        # update board state (reuse the before calculated treee)
        if self.root.hash and board_hash != self.root.hash:
            for his_turn in self.root.children:
                if his_turn.hash == board_hash:
                    self.root = his_turn
        else:
            self.root.hash = board_hash

        start = time.time()
        
        # fixed search time per turn: 0.5s
        time_slice = 0.5

        # reduce time_slice if we have to hurry up
        if self.time_left() < 4000:
            time_slice = 0.3

        lBoundRange = max(1,self.lastDepth-1)
        dephSearchRange = range(lBoundRange,42)
        for i in dephSearchRange:
            self.minmax(i, self.root)
            self.lastDepth = i
            if time.time() - start > time_slice:
                if self.debugMode:
                    print('current depth '+str(i)+' time:'+str(time.time() - start))
                break

        best_option = self.root.children[0]
        self.place_disc(best_option.play_col)
        self.root = best_option

    def expand_node(self, node):
        if node.value == sys.maxsize or node.value == -sys.maxsize:  # leaf node
            return

        player_id = self.id() if node.max_node else self.opponent_id()  # other player than node
        for col_nr in self.col_order:
            try:
                new_state = self.simulate_place_disc(node.state, col_nr, player_id)
            except Bot.ColumnFullException:
                continue
            new_node = Node(new_state, node)
            new_node.play_col = col_nr
            
            # do not calculate the same positions twice
            draft_node = self.transTable.get_entry(new_node,
                                                   self.last_played_stone_row,
                                                   self.last_played_stone_col,
                                                   player_id)
            
            if not draft_node:
                new_node.value = self.rate_state(new_node.state)
                
                self.transTable.add_entry(new_node,
                                          self.last_played_stone_row,
                                          self.last_played_stone_col,
                                          player_id)
                
            else:
                # if the board sate is already calculated: use the value from the Transposition Table
                new_node.value = draft_node.node.value
                new_node.hash = draft_node.node.hash
                
            node.children.append(new_node)

    def opponent_id(self):
        return 2 if self.id() == 1 else 1

    def heuristic(self, node):
        return node.value

    def rate_state(self, board):
        """ Rates the board. A higher value means a better chance to win. """
        board_sum = 0
        win_chances = set()

        for line in self.lines(board):
            value, wcs = SupiBot.rate_line(line)

            win_chances |= wcs

            if self.id() == 2:  # invert value if we are player 2
                value = -value
                        
            if value == sys.maxsize or value == -sys.maxsize:  # return if someone won
                return value

            board_sum += value

        # evaluate win chances
        # check for 2 win chances on top of each other. This will force a win
        win_chances_value = 0

        def get_double_win_chances(win_chances):
            double_win_chances = []
            for wc in win_chances:
                for wc2 in win_chances:
                    if wc[0][0]-1 == wc2[0][0] and wc[0][1] == wc2[0][1] and wc[1] == wc2[1]:
                        double_win_chances.append(wc)
            return double_win_chances

        dwcs = get_double_win_chances(win_chances)
        cut_win_chances = []
        for wc in win_chances:
            cut = False
            for dwc in dwcs:
                if dwc[0][0] > wc[0][0]+1 and dwc[0][1] == wc[0][1]:
                    cut = True
            if not cut:
                cut_win_chances.append(wc)
        dwcs = get_double_win_chances(cut_win_chances)

        for wc in cut_win_chances:
            win_chances_value += 20 if wc[1] == 1 else -20
        for dwc in dwcs:
            win_chances_value += 100 if wc[1] == 1 else -100

        board_sum += win_chances_value if self.id() == 1 else -win_chances_value
        return board_sum

    @staticmethod
    def rate_line(line):
        """ Rates the line from the perspective of player 1. """
        line_sum = 0
        win_chances = set()

        curr_player = 0  # the current owner of the last non-empty spot in the line
        take_over_idx = 0  # the index where the player took over
        win_spot = []  # placing a stone in this place will win the player the game

        consecutive_stones = 0
        player_stones = 0  # amount of stones of the curr player in the last 4 spots
        last_stone = 0

        for idx, (player, (row, col)) in enumerate(line):

            # add stones
            if player != 0:
                if player != curr_player:
                    # the other player takes over
                    if curr_player != 0:
                        take_over_idx = idx  # if there was not an earlier stone its all mine!
                    consecutive_stones = 1
                    player_stones = 1
                    curr_player = player

                else:
                    player_stones += 1

                    if last_stone == player:
                        consecutive_stones += 1

            # remove stones > 4 spaces away
            if idx >= 4 and idx - take_over_idx >= 3:
                rm_idx = idx - 4
                removed_stone = line[rm_idx][0]
                if removed_stone == curr_player:
                    player_stones -= 1
                    if line[rm_idx+1][0] == curr_player:  # check if we removed a consecutive stone
                        consecutive_stones -= 1

            # check the winn chance
            if curr_player != 0 and idx - take_over_idx >= 3:
                # check for win
                if player_stones == 4:
                    line_sum = sys.maxsize if curr_player == 1 else -sys.maxsize
                    return line_sum, set()

                # handle win chances in view of whole board
                elif player_stones == 3:
                    for i in range(take_over_idx, idx+1):
                        if line[i][0] == 0:  # found the free space
                            win_chance = tuple([line[i][1], curr_player])
                            win_chances |= set([win_chance])

                else:
                    value = player_stones * consecutive_stones
                    if curr_player == 1:
                        line_sum += value
                    else:
                        line_sum -= value

            # save last stone
            last_stone = player

        return line_sum, win_chances

    def lines_coords_arrays(self):
        """ Generates all lines on the board (also diagonals) and yields the  coordinates of those lines as lists.
        """

        idxs = np.indices((6, 7))

        for row in range(self.rows()):
            yield idxs[:, row]

        for col in range(self.cols()):
            yield idxs[:, :, col]

        for diag_nr in range(-(self.rows() - 4), self.cols() - 3):
            yield [np.diag(idxs[0], diag_nr), np.diag(idxs[1], diag_nr)]

        idxs[1] = np.fliplr(idxs[1])

        for diag_nr in range(-(self.rows() - 4), self.cols() - 3):
            yield [np.diag(idxs[0], diag_nr), np.diag(idxs[1], diag_nr)]

    def lines_coords(self):
        """ Generates coordinates of line segments
        """
        if self.cached_lines_coords:
            return self.cached_lines_coords
        self.cached_lines_coords = []
        for line in self.lines_coords_arrays():
            line_coords = []
            for idx in range(len(line[0])):
                line_coords.append(tuple([line[0][idx], line[1][idx]]))
            self.cached_lines_coords.append(line_coords)
        return self.cached_lines_coords

    def lines(self, board):
        for line in self.lines_coords():
            yield [tuple([board[coord[0], coord[1]], coord]) for coord in line]

if __name__ == '__main__':
    """ Run the bot! """
    SupiBot().run()
